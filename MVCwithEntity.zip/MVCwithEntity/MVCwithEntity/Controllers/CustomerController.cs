﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCwithEntity.Models;

namespace MVCwithEntity.Controllers
{
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/

        Training_18Jan2017_TalwadeEntities en = new Training_18Jan2017_TalwadeEntities();

        public ActionResult Index()
        {
            return View(en.Customer121785);
        }


        public ActionResult Details(int id)
        {

            return View(en.Customer121785.Find(id));
        }

        ///add details
        public ActionResult CreateCustomer()
        {

            return View();
        }

        [HttpPost]
        public ActionResult CreateCustomer(Customer121785 customer)
        {
            if (ModelState.IsValid)
            {
                en.Customer121785.Add(customer);
                en.SaveChanges();

                return RedirectToAction("Index");
            }
            else
            {
                return View(customer);
            }
        }

        //
        public ActionResult Edit(int id)
        {
            Customer121785 cst = en.Customer121785.Find(id);
            if (cst == null)
            {
                return HttpNotFound();
            }
            return View(cst);
        }
        [HttpPost]
        public ActionResult Edit(Customer121785 cst)
        {
            if (ModelState.IsValid)
            {
                en.Entry(cst).State = System.Data.EntityState.Modified;
                en.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(cst);
        }

        //\
        public ActionResult Delete(int id)
        {
            Customer121785 cst = en.Customer121785.Find(id);
            if (cst == null)
            {
                return HttpNotFound();
            }
            else
            {
                en.Customer121785.Remove(cst);
                en.SaveChanges();
                return RedirectToAction("Index");
            }
        }
        //\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        public ActionResult SearchCustomer(int id)
        {
            //EmployeeOperationEmployeeOperation = new EmployeeOperation();

            //Employee emp = EmployeeOperation.empList.Find(e => e.EmployeeId == id);

            Customer121785 cst = new Customer121785();
            cst = en.Customer121785.Find(e => e.id == cst.CustomerID);
           // emp = context.EmployeeDNs.First(e => e.empid == emps.empid);
            if (emp != null)
                return View(emp);
            else
                return Content("Employee Id does not Exist");
        }

    }
}
