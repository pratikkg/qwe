﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        //
        // GET: /Employee/

        public ActionResult DisplayEmployees()
        {
            //EmployeeOperationEmployeeOperation = new EmployeeOperation();

            ViewData["employees"] =EmployeeOperation.empList;

            return View();
        }

        // GET : Employee/SearchEmployee/1
        public ActionResult SearchEmployee(int id)
        {
            //EmployeeOperationEmployeeOperation = new EmployeeOperation();

            Employee emp =EmployeeOperation.empList.Find(e => e.EmployeeId == id);

            if (emp != null)
                return View(emp);
            else
                return Content("Employee Id does not Exist");
        }

        // GET : Employee/SearchEmployeeByCity/Pune
        public ActionResult SearchEmployeeByCity(string city)
        {
           // EmployeeOperationEmployeeOperation = new EmployeeOperation();
            List<Employee> emps = new List<Employee>();
            foreach (var emp in EmployeeOperation.empList)
            {
                if (emp.City == city)
                    emps.Add(emp);
            }
            return View(emps);
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CreateEmployee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateEmployee(Employee emp)
        {
            if (ModelState.IsValid)
            {
                //EmployeeOperationEmployeeOperation = new EmployeeOperation();
               EmployeeOperation.empList.Add(emp);

                return RedirectToAction("Index");
            }
            else
            {
                return View(emp);
            }
        }
        public ActionResult DeleteEmployee()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DeleteEmployee(Employee emp)
        {
            if (ModelState.IsValid)
            {
                EmployeeOperation.empList.Remove(emp);

                return RedirectToAction("Index");
            }
            else
            {
                return View(emp);
            }
        }

        public ActionResult UpdateEmployee(Employee emp)
        {
            return View();
        }

        [HttpPost]
        public ActionResult UpdateEmployee(Employee emp)
        {
            if (ModelState.IsValid)
            {
                EmployeeOperation.empList.Add(emp);

                return RedirectToAction("Index");
            }
            else
            {
                return View(emp);
            }
        }

    }
}
